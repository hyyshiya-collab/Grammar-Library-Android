# Grammar Library — Native Android starter

This is a Kotlin + Jetpack Compose Android project, not a website or WebView.

## Included in this first checkpoint
- Native Android app shell and bottom navigation
- Home, My Library placeholder, Games, Settings
- Four playable offline game prototypes: Memory Match, Sliding Puzzle, Tic Tac Toe, Whack-a-Mole
- Uploaded Grammar Library logo asset
- GitHub Actions workflow to build a debug APK in the cloud

## Not yet implemented
- Final animated opening screen using the logo
- Full Chat with Shiya and secure AI service
- Japanese/Thai grammar and dictionary databases
- Alphabet World, Theme World and persistent offline lesson storage
- Polished game timing, sound effects, levels, and final QA

This is an initial development checkpoint, not a finished app. Build and test before calling it release-ready.
