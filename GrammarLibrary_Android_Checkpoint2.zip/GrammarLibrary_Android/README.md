# Grammar Library — Native Android development checkpoint

Native Android project using Kotlin and Jetpack Compose. It is not a website or WebView.

## Included in this checkpoint
- Native Android navigation and starter screens
- Block Puzzle: 10x10 board, selectable shapes, row clearing and score
- Tile Match and Memory Match prototypes
- Sliding Puzzle, Tic Tac Toe and Whack-a-Mole prototypes
- User-provided logo image asset
- GitHub Actions workflow for a debug APK build

## Important status
This is still a development prototype, not the finished Grammar Library app.
The AI tutor, Japanese/Thai content databases, offline lesson persistence, animated logo opening,
full Theme World, richer game polish/sounds/levels, and device QA remain to be implemented.
The project must be built and tested before release.
