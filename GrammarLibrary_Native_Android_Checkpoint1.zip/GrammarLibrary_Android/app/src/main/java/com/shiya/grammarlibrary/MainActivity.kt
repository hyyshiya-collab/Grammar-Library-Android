package com.shiya.grammarlibrary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlin.random.Random

private val Ink = Color(0xFF211A2D)
private val Plum = Color(0xFF795477)
private val Rose = Color(0xFFE9B9C7)
private val Cream = Color(0xFFFFF8F1)
private val Lilac = Color(0xFFECE2F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(
            primary = Plum, secondary = Rose, background = Cream, surface = Color.White
        )) { GrammarLibraryApp() } }
    }
}

@Composable
fun GrammarLibraryApp() {
    var page by remember { mutableStateOf("Home") }
    var game by remember { mutableStateOf("") }
    Scaffold(containerColor = Cream, bottomBar = {
        NavigationBar(containerColor = Color.White) {
            listOf("Home", "Library", "Games", "Settings").forEach { item ->
                NavigationBarItem(selected = page == item, onClick = { page = item; game = "" },
                    icon = { Icon(when(item) {
                        "Home" -> Icons.Default.Home
                        "Library" -> Icons.Default.MenuBook
                        "Games" -> Icons.Default.SportsEsports
                        else -> Icons.Default.Settings
                    }, null) }, label = { Text(item) })
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            if (game.isNotEmpty()) GameScreen(game) { game = "" }
            else when(page) {
                "Home" -> HomeScreen(onGames = { page = "Games" })
                "Library" -> LibraryScreen()
                "Games" -> GamesScreen { game = it }
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().background(Ink).padding(22.dp)) {
        Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = Rose, fontSize = 14.sp)
    }
}

@Composable
fun HomeScreen(onGames: () -> Unit) {
    Header("Grammar Library", "A little world for Japanese & Thai learning")
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Lilac), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("こんにちは  •  สวัสดี", color = Plum, fontSize = 15.sp)
                Text("Your language journey\nstarts here.", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Learn gently. Save what you love.", color = Ink)
            }
        }
        Text("Explore your library", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        FeatureCard("Chat with Shiya", "Grammar help for Japanese & Thai", "✦")
        FeatureCard("Japanese & Thai", "Words, grammar and sentence practice", "文")
        FeatureCard("Alphabet World", "Start from the very first letters", "あ")
        FeatureCard("My Library", "Keep lessons for offline revision", "♡")
        Button(onClick = onGames, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.SportsEsports, null); Spacer(Modifier.width(8.dp)); Text("Explore Mini Games")
        }
        Text("This is the first native Android foundation. Learning modules and AI connection are staged for the next build.", color = Plum, fontSize = 12.sp)
    }
}

@Composable
fun FeatureCard(title: String, desc: String, symbol: String) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Lilac), contentAlignment = Alignment.Center) {
                Text(symbol, fontSize = 24.sp, color = Plum, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(13.dp))
            Column { Text(title, fontWeight = FontWeight.Bold, color = Ink); Text(desc, fontSize = 12.sp, color = Plum) }
        }
    }
}

@Composable
fun LibraryScreen() {
    Header("My Library", "Your saved lessons, always close")
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Saved lessons will appear here.", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("The offline lesson database and save/search flow are part of the next implementation checkpoint.", color = Plum)
    }
}

@Composable
fun GamesScreen(open: (String) -> Unit) {
    Header("Mini Games", "Play, collect points, and have fun")
    val games = listOf("Memory Match", "Sliding Puzzle", "Tic Tac Toe", "Whack-a-Mole")
    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(620.dp).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(games) { name ->
            Card(onClick = { open(name) }, shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(when(name) { "Memory Match" -> "🃏"; "Sliding Puzzle" -> "🧩"; "Tic Tac Toe" -> "⭕"; else -> "🐹" }, fontSize = 38.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(name, color = Ink, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("Tap to play", color = Plum, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun GameScreen(name: String, back: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("← Back to games", color = Plum, modifier = Modifier.clickable { back() })
        Text(name, fontSize = 25.sp, color = Ink, fontWeight = FontWeight.Bold)
        when(name) {
            "Memory Match" -> MemoryGame()
            "Sliding Puzzle" -> SlidingGame()
            "Tic Tac Toe" -> TicTacToeGame()
            else -> MoleGame()
        }
    }
}

@Composable
fun MemoryGame() {
    val icons = listOf("🌸","📚","🐱","🍵","🌙","🎀")
    var cards by remember { mutableStateOf((icons + icons).shuffled()) }
    var opened by remember { mutableStateOf(listOf<Int>()) }
    var matched by remember { mutableStateOf(setOf<Int>()) }
    var moves by remember { mutableIntStateOf(0) }
    Text("Moves: $moves   Matched: ${matched.size/2}/6", color = Plum)
    LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.height(330.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(cards.size) { i ->
            val show = i in opened || i in matched
            Box(Modifier.aspectRatio(0.8f).clip(RoundedCornerShape(14.dp))
                .background(if(show) Lilac else Plum).clickable {
                    if (!show && opened.size < 2) {
                        opened = opened + i
                        if (opened.size == 2) {
                            moves++
                            val pair = opened
                            if (cards[pair[0]] == cards[pair[1]]) matched = matched + pair
                            else { /* reset on next tap */ }
                        }
                    } else if (opened.size == 2 && i !in opened) {
                        opened = listOf(i)
                    }
                }, contentAlignment = Alignment.Center) {
                Text(if(show) cards[i] else "?", fontSize = 25.sp, color = Color.White)
            }
        }
    }
    if (matched.size == 12) Text("You did it! 🎉", color = Plum, fontSize = 22.sp)
    OutlinedButton(onClick = { cards = (icons+icons).shuffled(); opened = emptyList(); matched = emptySet(); moves = 0 }) { Text("Restart") }
}

@Composable
fun SlidingGame() {
    var tiles by remember { mutableStateOf((1..8).toList() + 0) }
    var moves by remember { mutableIntStateOf(0) }
    Text("Moves: $moves  •  Arrange 1 to 8", color = Plum)
    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(330.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(tiles.size) { i ->
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp))
                .background(if(tiles[i] == 0) Lilac else Plum)
                .clickable {
                    val empty = tiles.indexOf(0)
                    val adjacent = (i/3 == empty/3 && kotlin.math.abs(i-empty)==1) ||
                        (i%3 == empty%3 && kotlin.math.abs(i-empty)==3)
                    if(adjacent) { val n = tiles.toMutableList(); n[empty] = n[i]; n[i] = 0; tiles = n; moves++ }
                }, contentAlignment = Alignment.Center) {
                if(tiles[i] != 0) Text("${tiles[i]}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
    if(tiles == (1..8).toList()+0) Text("Puzzle solved! ✨", color = Plum)
    OutlinedButton(onClick = { tiles = (1..8).toList().shuffled() + 0; moves = 0 }) { Text("Shuffle") }
}

@Composable
fun TicTacToeGame() {
    var cells by remember { mutableStateOf(List(9) { "" }) }
    var turn by remember { mutableStateOf("X") }
    val wins = listOf(listOf(0,1,2),listOf(3,4,5),listOf(6,7,8),listOf(0,3,6),listOf(1,4,7),listOf(2,5,8),listOf(0,4,8),listOf(2,4,6))
    val winner = wins.firstOrNull { cells[it[0]].isNotEmpty() && cells[it[0]] == cells[it[1]] && cells[it[1]] == cells[it[2]] }?.let { cells[it[0]] }
    Text(if(winner != null) "$winner wins! 🎉" else if(cells.all { it.isNotEmpty() }) "Draw!" else "Turn: $turn", color = Plum)
    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(330.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(9) { i ->
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(Lilac).clickable {
                if(cells[i].isEmpty() && winner == null) { val n=cells.toMutableList(); n[i]=turn; cells=n; turn=if(turn=="X") "O" else "X" }
            }, contentAlignment = Alignment.Center) { Text(cells[i], fontSize = 38.sp, color = Plum, fontWeight = FontWeight.Bold) }
        }
    }
    OutlinedButton(onClick = { cells = List(9){""}; turn = "X" }) { Text("Play again") }
}

@Composable
fun MoleGame() {
    var score by remember { mutableIntStateOf(0) }
    var mole by remember { mutableIntStateOf(Random.nextInt(9)) }
    var taps by remember { mutableIntStateOf(0) }
    Text("Score: $score   •   Hits left: ${20-taps}", color = Plum)
    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(330.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(9) { i ->
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                .background(if(i==mole) Rose else Lilac).clickable {
                    if(taps < 20) { if(i==mole) score++; taps++; mole=Random.nextInt(9) }
                }, contentAlignment = Alignment.Center) { Text(if(i==mole) "🐹" else "🌱", fontSize = 30.sp) }
        }
    }
    if(taps >= 20) Text("Round complete! Final score: $score", color = Plum, fontSize = 20.sp)
    OutlinedButton(onClick = { score=0; taps=0; mole=Random.nextInt(9) }) { Text("Play again") }
}

@Composable
fun SettingsScreen() {
    Header("Settings", "Make your learning space yours")
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        FeatureCard("Theme World", "More visual themes and matching artwork", "✿")
        FeatureCard("Language", "Tamil & English explanations", "文")
        FeatureCard("Sound", "Game sound and app preferences", "♫")
        Text("Theme switching, chat service, and learning preferences will be completed in later checkpoints.", color = Plum)
    }
}
